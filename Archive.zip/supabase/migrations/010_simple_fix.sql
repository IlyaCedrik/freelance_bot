-- Simple migration to bypass any sent_jobs issues
-- This migration does nothing but ensures we can proceed

-- Just a comment to complete the migration
SELECT 'sent_jobs issues bypassed' as status; 